To make a sample ICCP paper, use LaTeX (or the TeX flavor of 
your choice, e.g. pdfLaTeX) to build the example file:
iccppaper_final.tex


To make a copy with the review style (for anonymous review and 
including line numbers) use "iccppaper_for_review.tex" instead
of "iccppaper_final.tex".